import React from 'react';
// import { Bracket, RoundProps } from 'react-brackets';
import { Col, Row } from 'reactstrap';
import '../../../assets/styles/sheet-style.scss';
import { FaMedal } from 'react-icons/fa';
function BracketEight() {
  return (
    <div>
      <div className="tournament tournament--double-elimination">
        <div className="tournament__logo-container tournament__logo-container--right">
          <strong className="tournament__logo tournament__logo--gold"></strong>
        </div>
        <div className="tournament__grid">
          <div className="tournament__round tournament__round--first-round">
            <div className="tournament__match">
              <a href="#" className="tournament__match__status">
                <span className="tournament__match__status__container">
                  <span className="team__result">
                    <span className="team__result__left team__result--win">3</span> :{' '}
                    <span className="team__result__right">1</span>
                  </span>
                </span>
              </a>
              <a className="tournament__match__team" href="#">
                <i className="tournament__match__team__icon"></i>
                <span className="tournament__match__team__title top">lorem</span>
                <p
                  className="tournament__match__team__title"
                  style={{ color: '#000', fontSize: '10px' }}
                >
                  School Name Here
                </p>
              </a>
              <a className="tournament__match__team" href="#">
                <i className="tournament__match__team__icon"></i>
                <span className="tournament__match__team__title bot">lorem</span>
                <p
                  className="tournament__match__team__title"
                  style={{ color: '#000', fontSize: '10px' }}
                >
                  School Name Here
                </p>
              </a>
            </div>
            <div className="tournament__match">
              <a href="#" className="tournament__match__status">
                <span className="tournament__match__status__container">
                  <span className="team__result">
                    <span className="team__result__left team__result--win">3</span> :{' '}
                    <span className="team__result__right">1</span>
                  </span>
                </span>
              </a>
              <a className="tournament__match__team" href="#">
                <i className="tournament__match__team__icon"></i>
                <span className="tournament__match__team__title top">lorem</span>
                <p
                  className="tournament__match__team__title"
                  style={{ color: '#000', fontSize: '10px' }}
                >
                  School Name Here
                </p>
              </a>
              <a className="tournament__match__team" href="#">
                <i className="tournament__match__team__icon"></i>
                <span className="tournament__match__team__title bot">lorem</span>
                <p
                  className="tournament__match__team__title"
                  style={{ color: '#000', fontSize: '10px' }}
                >
                  School Name Here
                </p>
              </a>
            </div>
          </div>

          <div className="tournament__round">
            <div className="tournament__match">
              <a href="#" className="tournament__match__status">
                <span className="tournament__match__status__container">
                  <span className="state--live">live</span>
                </span>
              </a>
              <a className="tournament__match__team" href="#">
                <i className="tournament__match__team__icon"></i>
                <span className="tournament__match__team__title top">lorem</span>
                <p
                  className="tournament__match__team__title"
                  style={{ color: '#000', fontSize: '10px' }}
                >
                  School Name Here
                </p>
              </a>
              <a className="tournament__match__team" href="#">
                <i className="tournament__match__team__icon"></i>
                <span className="tournament__match__team__title bot">lorem</span>
                <p
                  className="tournament__match__team__title"
                  style={{ color: '#000', fontSize: '10px' }}
                >
                  School Name Here
                </p>
              </a>
            </div>
          </div>
          <div className="tournament__round">
            <div className="tournament__match first-round">
              <a href="#" className="tournament__match__status">
                <span className="tournament__match__status__container">
                  <span className="state--live">live</span>
                </span>
              </a>
              <a className="tournament__match__team" href="#">
                <i className="tournament__match__team__icon"></i>
                <span className="tournament__match__team__title top">lorem</span>
                <p
                  className="tournament__match__team__title"
                  style={{ color: '#000', fontSize: '10px' }}
                >
                  School Name Here
                </p>
              </a>
            </div>
          </div>
          {/* <div className="tournament__round">
            <div className="tournament__match">
              <a href="#" className="tournament__match__status">
                <span className="tournament__match__status__container">
                  <span className="team__schedulded"></span>
                </span>
              </a>
              <a className="tournament__match__team" href="#">
                <i className="tournament__match__team__icon"></i>
                <span className="tournament__match__team__title top">lorem</span>
                <p
                  className="tournament__match__team__title"
                  style={{ color: '#000', fontSize: '10px' }}
                >
                  School Name Here
                </p>
              </a>
              <a className="tournament__match__team" href="#">
                <i className="tournament__match__team__icon"></i>
                <span className="tournament__match__team__title bot">lorem</span>
                <p
                  className="tournament__match__team__title"
                  style={{ color: '#000', fontSize: '10px' }}
                >
                  School Name Here
                </p>
              </a>
            </div>
          </div> */}

          <div className="tournament__round tournament__round--final">
            <div className="tournament__match">
              {/* <a href="#" className="tournament__match__status">
                <span className="tournament__match__status__container">
                  <span className="team__result mt-1">
                    <span
                      className="team__result__left team__result--win"
                      style={{ color: 'green' }}
                    >
                      Gold
                    </span>
                    <span className="team__result__right" style={{ color: 'green' }}>
                      Medal
                    </span>
                    <span>
                      <FaMedal fill="#EEBC1D" fontSize="30" style={{ margin: ' 0px 25px' }} />
                    </span>
                  </span>
                </span>
              </a> */}
              <a className="tournament__match__team" href="#">
                <i className="tournament__match__team__icon"></i>
                <span className="tournament__match__team__title ">First Rank</span>
                {/* <p
                  className="tournament__match__team__title"
                  style={{ color: '#000', fontSize: '10px' }}
                >
                  School Name Here
                </p> */}
              </a>
              {/* <a className="tournament__match__team" href="#">
                <i className="tournament__match__team__icon"></i>
                <span className="tournament__match__team__title bot">lorem</span>
                <p
                  className="tournament__match__team__title"
                  style={{ color: '#000', fontSize: '10px' }}
                >
                  School Name Here
                </p>
              </a> */}
            </div>
          </div>

          <div className="tournament__round tournament__round--right-bracket">
            <div className="tournament__match first-round">
              <a href="#" className="tournament__match__status">
                <span className="tournament__match__status__container">
                  <span className="state--live">live</span>
                </span>
              </a>
              <a className="tournament__match__team" href="#">
                <i className="tournament__match__team__icon"></i>
                <span className="tournament__match__team__title bot">lorem</span>
                <p
                  className="tournament__match__team__title"
                  style={{ color: '#000', fontSize: '10px' }}
                >
                  School Name Here
                </p>
              </a>
            </div>
          </div>
          <div className="tournament__round tournament__round--right-bracket">
            <div className="tournament__match">
              <a href="#" className="tournament__match__status">
                <span className="tournament__match__status__container">
                  <span className="state--live">live</span>
                </span>
              </a>
              <a className="tournament__match__team" href="#">
                <i className="tournament__match__team__icon"></i>
                <span className="tournament__match__team__title top">lorem</span>
                <p
                  className="tournament__match__team__title"
                  style={{ color: '#000', fontSize: '10px' }}
                >
                  School Name Here
                </p>
              </a>
              <a className="tournament__match__team" href="#">
                <i className="tournament__match__team__icon"></i>
                <span className="tournament__match__team__title bot">lorem</span>
                <p
                  className="tournament__match__team__title"
                  style={{ color: '#000', fontSize: '10px' }}
                >
                  School Name Here
                </p>
              </a>
            </div>
          </div>
          <div className="tournament__round tournament__round--right-bracket">
            <div className="tournament__match">
              <a href="#" className="tournament__match__status">
                <span className="tournament__match__status__container">
                  <span className="team__result">
                    <span className="team__result__left team__result--win">3</span> :{' '}
                    <span className="team__result__right">1</span>
                  </span>
                </span>
              </a>
              <a className="tournament__match__team" href="#">
                <i className="tournament__match__team__icon"></i>
                <span className="tournament__match__team__title top">lorem</span>
                <p
                  className="tournament__match__team__title"
                  style={{ color: '#000', fontSize: '10px' }}
                >
                  School Name Here
                </p>
              </a>
              <a className="tournament__match__team" href="#">
                <i className="tournament__match__team__icon"></i>
                <span className="tournament__match__team__title bot">lorem</span>
                <p
                  className="tournament__match__team__title"
                  style={{ color: '#000', fontSize: '10px' }}
                >
                  School Name Here
                </p>
              </a>
            </div>
            <div className="tournament__match">
              <a href="#" className="tournament__match__status">
                <span className="tournament__match__status__container">
                  <span className="team__result">
                    <span className="team__result__left team__result--win">3</span> :{' '}
                    <span className="team__result__right">1</span>
                  </span>
                </span>
              </a>
              <a className="tournament__match__team" href="#">
                <i className="tournament__match__team__icon"></i>
                <span className="tournament__match__team__title top">lorem</span>
                <p
                  className="tournament__match__team__title"
                  style={{ color: '#000', fontSize: '10px' }}
                >
                  School Name Here
                </p>
              </a>
              <a className="tournament__match__team" href="#">
                <i className="tournament__match__team__icon"></i>
                <span className="tournament__match__team__title bot">lorem</span>
                <p
                  className="tournament__match__team__title"
                  style={{ color: '#000', fontSize: '10px' }}
                >
                  School Name Here
                </p>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default BracketEight;
