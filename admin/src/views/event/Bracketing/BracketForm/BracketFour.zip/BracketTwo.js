import React from 'react';
import '../../../assets/styles/sheet-style.scss';
function BracketTwo() {
  return (
    <div>
      <div className="tournament tournament--double-elimination">
        <div className="tournament__logo-container tournament__logo-container--right">
          <strong className="tournament__logo tournament__logo--gold"></strong>
        </div>
        <div className="tournament__grid">
          <div className="tournament__round tournament__round--first-round">
            <div className="tournament__match first-round">
              <a href="#" className="tournament__match__status">
                <span className="tournament__match__status__container">
                  <span className="team__result">
                    <span className="team__result__left team__result--win">3</span> :{' '}
                    <span className="team__result__right">1</span>
                  </span>
                </span>
              </a>
              <a className="tournament__match__team" href="#">
                <i className="tournament__match__team__icon"></i>
                <span className="tournament__match__team__title top">lorem</span>
                <p
                  className="tournament__match__team__title"
                  style={{ color: '#000', fontSize: '10px' }}
                >
                  School Name Here
                </p>
              </a>
            </div>
          </div>
          <div className="tournament__round tournament__round--final">
            <div className="tournament__match">
              <a href="#" className="tournament__match__status"></a>
              <a className="tournament__match__team" href="#">
                <i className="tournament__match__team__icon"></i>
                <span className="tournament__match__team__title">First Rank</span>
              </a>
            </div>
          </div>
          <div className="tournament__round tournament__round--right-bracket">
            <div className="tournament__match first-round">
              <a href="#" className="tournament__match__status">
                <span className="tournament__match__status__container">
                  <span className="team__schedulded"></span>
                </span>
              </a>
              <a className="tournament__match__team" href="#">
                <i className="tournament__match__team__icon"></i>
                <span className="tournament__match__team__title bot">lorem</span>
                <p
                  className="tournament__match__team__title"
                  style={{ color: '#000', fontSize: '10px' }}
                >
                  School Name Here
                </p>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default BracketTwo;
