import { right } from '@patternfly/react-core/dist/esm/helpers/Popper/thirdparty/popper-core';
import React from 'react';
import { BiBorderBottom } from 'react-icons/bi';
import {
  Button,
  Card,
  CardBody,
  CardHeader,
  Col,
  Input,
  CardTitle,
  FormGroup,
  CardText,
  Table,
  Label,
  Modal,
  ModalBody,
  ModalFooter,
  ModalHeader,
  Row
} from 'reactstrap';

import '../../../assets/styles/sheet-style.scss';
// import ErDiagramTwo from './ErDiagramTwo';
// import ErDiagram from './ErDiagram';
import BracketSixteen from './BracketSixteen';
import BracketFour from './BracketFour';
import BracketTwo from './BracketTwo';
import BracketEight from './BracketEight';
import BracketThirtyTwo from './BracketThirtyTwo';
function DivisionSheet() {
  return (
    <>
      <div className="container-fluid">
        <div style={{ textAlign: 'right', marginRight: '20px', marginTop: '20px' }}>
          <button className="btn btn-primary" onClick={() => window.print()}>
            Print
          </button>
          <a href="/event-view-list" className="btn btn-primary" style={{ marginLeft: '10px' }}>
            Back
          </a>
        </div>
        <br></br>
        {/* second section start */}
        <div style={{ width: '100%' }}>
          <div>
            <p style={{ textAlign: 'center' }}>[Page Number 01]</p>
          </div>
          {/* table score card  */}
          <div style={{ border: '1px solid#000' }}>
            <h2
              style={{
                fontSize: '18px',
                borderBottom: '1px solid#000',
                padding: '10px'
              }}
            >
              Black Belt Breaking
              <span style={{ fontSize: '12px', marginLeft: '5px' }}>
                (2021 ChampionsNational Toumament J)
              </span>
            </h2>
            <div className="d-flex" style={{ borderBottom: '1px solid#000', padding: '4px' }}>
              <p style={{ width: '30%' }}>Division.(1601) Junior.Black Belt</p>
              <p style={{ width: '10%', textAlign: 'center' }}>Gender - F</p>
              <p style={{ width: '10%', textAlign: 'center' }}>Age 8 - 9</p>
              <p style={{ width: '20%', textAlign: 'center' }}>Rank.CMA 1st Don. CMA 4th Don</p>
              <p style={{ width: '30%', textAlign: 'right' }}>WeiQhl: 0.0.999.0</p>
            </div>
            <div>
              <table
                style={{
                  fontFamily: 'arial, sans-serif',
                  borderCollapse: 'collapse',
                  width: '100%'
                }}
              >
                <tr>
                  <th style={{ border: '1px solid#000', textAlign: 'left', padding: '4px' }}>
                    (ID)Member
                  </th>
                </tr>
                <tr>
                  <th style={{ border: '1px solid#000', textAlign: 'left', padding: '4px' }}>
                    <input
                      type="text"
                      placeholder="(1 - 1) Wu,Logan: 70.0 {age 9). CMA 1st Dan"
                      style={{ borderColor: '#ccc0', width: '100%' }}
                    ></input>
                  </th>
                </tr>
                <tr>
                  <th style={{ border: '1px solid#000', textAlign: 'left', padding: '4px' }}>
                    <input
                      type="text"
                      placeholder="'(2.2) Ibrahim,Emmanuel:50.0 (age 9) .CMA 1st Dan"
                      style={{ borderColor: '#ccc0', width: '100%' }}
                    ></input>
                  </th>
                </tr>
                <tr>
                  <th style={{ border: '1px solid#000', textAlign: 'left', padding: '4px' }}>
                    <input
                      type="text"
                      placeholder="(3.3) MANNINA,THOMAS :48 0 {age 8). CMA 1SIDan"
                      style={{ borderColor: '#ccc0', width: '100%' }}
                    ></input>
                  </th>
                </tr>
                <tr>
                  <th style={{ border: '1px solid#000', textAlign: 'left', padding: '4px' }}>
                    <input
                      type="text"
                      placeholder=""
                      style={{ borderColor: '#ccc0', width: '100%' }}
                    ></input>
                  </th>
                </tr>
                <tr>
                  <th style={{ border: '1px solid#000', textAlign: 'left', padding: '4px' }}>
                    <input
                      type="text"
                      placeholder=""
                      style={{ borderColor: '#ccc0', width: '100%' }}
                    ></input>
                  </th>
                </tr>
              </table>
            </div>
          </div>
          {/* table score card  close*/}

          {/* compare  section */}
          <div style={{ width: '100%', marginTop: '10px' }}>
            <BracketTwo />
          </div>

          {/* compare section close*/}
          {/* second table result*/}
          <div style={{ border: '1px solid#000' }}>
            <h2
              style={{
                fontSize: '18px',
                borderBottom: '1px solid#000',
                padding: '10px',
                textAlign: 'center',
                marginBottom: '0px'
              }}
            >
              Result
            </h2>

            <div>
              <table
                style={{
                  fontFamily: 'arial, sans-serif',
                  borderCollapse: 'collapse',
                  width: '100%'
                }}
              >
                <tr>
                  <th
                    style={{
                      border: '1px solid#000',
                      textAlign: 'left',
                      padding: '4px',
                      width: '30%'
                    }}
                  >
                    First Place
                  </th>
                  <td style={{ border: '1px solid#000', textAlign: 'left', padding: '4px' }}>
                    <input type="text" style={{ borderColor: '#ccc0', width: '100%' }}></input>
                  </td>
                </tr>
                <tr>
                  <th
                    style={{
                      border: '1px solid#000',
                      textAlign: 'left',
                      padding: '4px',
                      width: '30%'
                    }}
                  >
                    Second Place
                  </th>
                  <td style={{ border: '1px solid#000', textAlign: 'left', padding: '4px' }}>
                    <input type="text" style={{ borderColor: '#ccc0', width: '100%' }}></input>
                  </td>
                </tr>
                <tr>
                  <th
                    style={{
                      border: '1px solid#000',
                      textAlign: 'left',
                      padding: '4px',
                      width: '30%'
                    }}
                  >
                    Third Place
                  </th>
                  <td style={{ border: '1px solid#000', textAlign: 'left', padding: '4px' }}>
                    <input type="text" style={{ borderColor: '#ccc0', width: '100%' }}></input>
                  </td>
                </tr>
                <tr>
                  <th
                    style={{
                      border: '1px solid#000',
                      textAlign: 'left',
                      padding: '4px',
                      width: '30%'
                    }}
                  >
                    Fourth Place
                  </th>
                  <td style={{ border: '1px solid#000', textAlign: 'left', padding: '4px' }}>
                    <input type="text" style={{ borderColor: '#ccc0', width: '100%' }}></input>
                  </td>
                </tr>
                <tr>
                  <th
                    style={{
                      border: '1px solid#000',
                      textAlign: 'left',
                      padding: '4px',
                      width: '30%'
                    }}
                  >
                    51h Place ( Finalist)
                  </th>
                  <td style={{ border: '1px solid#000', textAlign: 'left', padding: '4px' }}>
                    <input type="text" style={{ borderColor: '#ccc0', width: '100%' }}></input>
                  </td>
                </tr>
                <tr>
                  <th
                    style={{
                      border: '1px solid#000',
                      textAlign: 'left',
                      padding: '4px',
                      width: '30%'
                    }}
                  >
                    Sixth Place ( Finalist)
                  </th>
                  <td style={{ border: '1px solid#000', textAlign: 'left', padding: '4px' }}>
                    <input type="text" style={{ borderColor: '#ccc0', width: '100%' }}></input>
                  </td>
                </tr>
                <tr>
                  <th
                    style={{
                      border: '1px solid#000',
                      textAlign: 'left',
                      padding: '4px',
                      width: '30%'
                    }}
                  >
                    Saventh Place ( Finalist)
                  </th>
                  <td style={{ border: '1px solid#000', textAlign: 'left', padding: '4px' }}>
                    <input type="text" style={{ borderColor: '#ccc0', width: '100%' }}></input>
                  </td>
                </tr>
                <tr>
                  <th
                    style={{
                      border: '1px solid#000',
                      textAlign: 'left',
                      padding: '4px',
                      width: '30%'
                    }}
                  >
                    Eighth Place ( Finalist)
                  </th>
                  <td style={{ border: '1px solid#000', textAlign: 'left', padding: '4px' }}>
                    <input type="text" style={{ borderColor: '#ccc0', width: '100%' }}></input>
                  </td>
                </tr>
              </table>
            </div>
          </div>
          {/* second table result close */}
        </div>

        {/* second section close */}

        {/* third section start */}
        <div style={{ width: '100%', marginTop: '30px', marginBottom: '30px' }}>
          <div>
            <p style={{ textAlign: 'center' }}>[Page Number 02]</p>
          </div>
          {/* table score card  */}
          <div style={{ border: '1px solid#000' }}>
            <h2
              style={{
                fontSize: '18px',
                borderBottom: '1px solid#000',
                padding: '10px'
              }}
            >
              Black Belt Breaking
              <span style={{ fontSize: '12px', marginLeft: '5px' }}>
                (12021 Champ1onsNa:1onanournamen1 J)
              </span>
            </h2>
            <div className="d-flex" style={{ borderBottom: '1px solid#000', padding: '4px' }}>
              <p style={{ width: '30%' }}>Division·(1602) Junior.Black Belt</p>
              <p style={{ width: '10%', textAlign: 'center' }}>Gender. F</p>
              <p style={{ width: '10%', textAlign: 'center' }}>Age:B.9</p>
              <p style={{ width: '20%', textAlign: 'center' }}>Rank: CMA 1SI Dan.CMA4tl Dan</p>
              <p style={{ width: '30%', textAlign: 'right' }}>Weight 0.0. 999.0</p>
            </div>
            <div>
              <table
                style={{
                  fontFamily: 'arial, sans-serif',
                  borderCollapse: 'collapse',
                  width: '100%'
                }}
              >
                <tr>
                  <th style={{ border: '1px solid#000', textAlign: 'left', padding: '4px' }}>
                    (ID)Member
                  </th>
                </tr>
                <tr>
                  <th style={{ border: '1px solid#000', textAlign: 'left', padding: '4px' }}>
                    <input
                      type="text"
                      placeholder="(1 •4) Feder, Miranda :85.0(age 9).CMA 1st Dan"
                      style={{ borderColor: '#ccc0', width: '100%' }}
                    ></input>
                  </th>
                </tr>
                <tr>
                  <th style={{ border: '1px solid#000', textAlign: 'left', padding: '4px' }}>
                    <input
                      type="text"
                      placeholder=""
                      style={{ borderColor: '#ccc0', width: '100%' }}
                    ></input>
                  </th>
                </tr>
              </table>
            </div>
          </div>
          {/* table score card  close*/}

          {/* compare  section */}
          <div style={{ width: '100%', marginTop: '10px', marginBottom: '30px' }}>
            <BracketFour />
          </div>

          {/* compare section close*/}
          {/* second table result*/}
          <div style={{ border: '1px solid#000' }}>
            <h2
              style={{
                fontSize: '18px',
                borderBottom: '1px solid#000',
                padding: '10px',
                textAlign: 'center',
                marginBottom: '0px'
              }}
            >
              Result
            </h2>

            <div>
              <table
                style={{
                  fontFamily: 'arial, sans-serif',
                  borderCollapse: 'collapse',
                  width: '100%'
                }}
              >
                <tr>
                  <th
                    style={{
                      border: '1px solid#000',
                      textAlign: 'left',
                      padding: '4px',
                      width: '30%'
                    }}
                  >
                    First Place
                  </th>
                  <td style={{ border: '1px solid#000', textAlign: 'left', padding: '4px' }}>
                    <input type="text" style={{ borderColor: '#ccc0', width: '100%' }}></input>
                  </td>
                </tr>
                <tr>
                  <th
                    style={{
                      border: '1px solid#000',
                      textAlign: 'left',
                      padding: '4px',
                      width: '30%'
                    }}
                  >
                    Second Place
                  </th>
                  <td style={{ border: '1px solid#000', textAlign: 'left', padding: '4px' }}>
                    <input type="text" style={{ borderColor: '#ccc0', width: '100%' }}></input>
                  </td>
                </tr>
                <tr>
                  <th
                    style={{
                      border: '1px solid#000',
                      textAlign: 'left',
                      padding: '4px',
                      width: '30%'
                    }}
                  >
                    Third Place
                  </th>
                  <td style={{ border: '1px solid#000', textAlign: 'left', padding: '4px' }}>
                    <input type="text" style={{ borderColor: '#ccc0', width: '100%' }}></input>
                  </td>
                </tr>
                <tr>
                  <th
                    style={{
                      border: '1px solid#000',
                      textAlign: 'left',
                      padding: '4px',
                      width: '30%'
                    }}
                  >
                    Fourth Place
                  </th>
                  <td style={{ border: '1px solid#000', textAlign: 'left', padding: '4px' }}>
                    <input type="text" style={{ borderColor: '#ccc0', width: '100%' }}></input>
                  </td>
                </tr>
                <tr>
                  <th
                    style={{
                      border: '1px solid#000',
                      textAlign: 'left',
                      padding: '4px',
                      width: '30%'
                    }}
                  >
                    51h Place ( Finalist)
                  </th>
                  <td style={{ border: '1px solid#000', textAlign: 'left', padding: '4px' }}>
                    <input type="text" style={{ borderColor: '#ccc0', width: '100%' }}></input>
                  </td>
                </tr>
                <tr>
                  <th
                    style={{
                      border: '1px solid#000',
                      textAlign: 'left',
                      padding: '4px',
                      width: '30%'
                    }}
                  >
                    Sixth Place ( Finalist)
                  </th>
                  <td style={{ border: '1px solid#000', textAlign: 'left', padding: '4px' }}>
                    <input type="text" style={{ borderColor: '#ccc0', width: '100%' }}></input>
                  </td>
                </tr>
                <tr>
                  <th
                    style={{
                      border: '1px solid#000',
                      textAlign: 'left',
                      padding: '4px',
                      width: '30%'
                    }}
                  >
                    Saventh Place ( Finalist)
                  </th>
                  <td style={{ border: '1px solid#000', textAlign: 'left', padding: '4px' }}>
                    <input type="text" style={{ borderColor: '#ccc0', width: '100%' }}></input>
                  </td>
                </tr>
                <tr>
                  <th
                    style={{
                      border: '1px solid#000',
                      textAlign: 'left',
                      padding: '4px',
                      width: '30%'
                    }}
                  >
                    Eighth Place ( Finalist)
                  </th>
                  <td style={{ border: '1px solid#000', textAlign: 'left', padding: '4px' }}>
                    <input type="text" style={{ borderColor: '#ccc0', width: '100%' }}></input>
                  </td>
                </tr>
              </table>
            </div>
          </div>
          {/* second table result close */}
        </div>

        {/* third section close  */}

        {/* block-3 start */}

        <div style={{ width: '100%', marginTop: '30px', marginBottom: '30px' }}>
          <div>
            <p style={{ textAlign: 'center' }}>[Page Number 03]</p>
          </div>
          {/* table score card  */}
          <div style={{ border: '1px solid#000' }}>
            <h2
              style={{
                fontSize: '18px',
                borderBottom: '1px solid#000',
                padding: '10px'
              }}
            >
              Black Belt Breaking
              <span style={{ fontSize: '12px', marginLeft: '5px' }}>
                ( 2021 Champions National Tournament)
              </span>
            </h2>
            <div className="d-flex" style={{ borderBottom: '1px solid#000', padding: '4px' }}>
              <p style={{ width: '30%' }}>Divis on·(160J) Junior -1st Dan Black Belt</p>
              <p style={{ width: '10%', textAlign: 'center' }}>Gender M</p>
              <p style={{ width: '10%', textAlign: 'center' }}>Age.10.11</p>
              <p style={{ width: '20%', textAlign: 'center' }}>Rani CMA 1$1 Dan • CMA 1$1 Dan</p>
              <p style={{ width: '30%', textAlign: 'right' }}> We!Oht 0.0 • 999.0</p>
            </div>
            <div>
              <table
                style={{
                  fontFamily: 'arial, sans-serif',
                  borderCollapse: 'collapse',
                  width: '100%'
                }}
              >
                <tr>
                  <th style={{ border: '1px solid#000', textAlign: 'left', padding: '4px' }}>
                    (ID)Member
                  </th>
                </tr>
                <tr>
                  <th style={{ border: '1px solid#000', textAlign: 'left', padding: '4px' }}>
                    <input
                      type="text"
                      placeholder="(1 • 5) Clark,Robert :85,0 (age 11).CMA 1st Dan"
                      style={{ borderColor: '#ccc0', width: '100%' }}
                    ></input>
                  </th>
                </tr>
                <tr>
                  <th style={{ border: '1px solid#000', textAlign: 'left', padding: '4px' }}>
                    <input
                      type="text"
                      placeholder="2 •6) Herrera Furmanov, Arthur: 67.0 (age 10) .CMA 1st Dan"
                      style={{ borderColor: '#ccc0', width: '100%' }}
                    ></input>
                  </th>
                </tr>
                <tr>
                  <th style={{ border: '1px solid#000', textAlign: 'left', padding: '4px' }}>
                    <input
                      type="text"
                      placeholder="(3 • 7) Islam,Jamie :104.0 (age 11) • CMA 1st Dan"
                      style={{ borderColor: '#ccc0', width: '100%' }}
                    ></input>
                  </th>
                </tr>
                <tr>
                  <th style={{ border: '1px solid#000', textAlign: 'left', padding: '4px' }}>
                    <input
                      type="text"
                      placeholder="(4 • 8) Gimm, Bnrndon :72.0 (age 10).CMA 1st Dan"
                      style={{ borderColor: '#ccc0', width: '100%' }}
                    ></input>
                  </th>
                </tr>
                <tr>
                  <th style={{ border: '1px solid#000', textAlign: 'left', padding: '4px' }}>
                    <input
                      type="text"
                      placeholder="6 - 10) LIANG, Tyler: 70.0 (age 10) .CMA 1st Dan"
                      style={{ borderColor: '#ccc0', width: '100%' }}
                    ></input>
                  </th>
                </tr>
              </table>
            </div>
          </div>
          {/* table score card  close*/}

          {/* compare  section */}
          <div style={{ width: '100%', marginTop: '10px', marginBottom: '30px' }}>
            <BracketEight />
          </div>

          {/* compare section close*/}
          {/* second table result*/}
          <div style={{ border: '1px solid#000' }}>
            <h2
              style={{
                fontSize: '18px',
                borderBottom: '1px solid#000',
                padding: '10px',
                textAlign: 'center',
                marginBottom: '0px'
              }}
            >
              Result
            </h2>

            <div>
              <table
                style={{
                  fontFamily: 'arial, sans-serif',
                  borderCollapse: 'collapse',
                  width: '100%'
                }}
              >
                <tr>
                  <th
                    style={{
                      border: '1px solid#000',
                      textAlign: 'left',
                      padding: '4px',
                      width: '30%'
                    }}
                  >
                    First Place
                  </th>
                  <td style={{ border: '1px solid#000', textAlign: 'left', padding: '4px' }}>
                    <input type="text" style={{ borderColor: '#ccc0', width: '100%' }}></input>
                  </td>
                </tr>
                <tr>
                  <th
                    style={{
                      border: '1px solid#000',
                      textAlign: 'left',
                      padding: '4px',
                      width: '30%'
                    }}
                  >
                    Second Place
                  </th>
                  <td style={{ border: '1px solid#000', textAlign: 'left', padding: '4px' }}>
                    <input type="text" style={{ borderColor: '#ccc0', width: '100%' }}></input>
                  </td>
                </tr>
                <tr>
                  <th
                    style={{
                      border: '1px solid#000',
                      textAlign: 'left',
                      padding: '4px',
                      width: '30%'
                    }}
                  >
                    Third Place
                  </th>
                  <td style={{ border: '1px solid#000', textAlign: 'left', padding: '4px' }}>
                    <input type="text" style={{ borderColor: '#ccc0', width: '100%' }}></input>
                  </td>
                </tr>
                <tr>
                  <th
                    style={{
                      border: '1px solid#000',
                      textAlign: 'left',
                      padding: '4px',
                      width: '30%'
                    }}
                  >
                    Fourth Place
                  </th>
                  <td style={{ border: '1px solid#000', textAlign: 'left', padding: '4px' }}>
                    <input type="text" style={{ borderColor: '#ccc0', width: '100%' }}></input>
                  </td>
                </tr>
                <tr>
                  <th
                    style={{
                      border: '1px solid#000',
                      textAlign: 'left',
                      padding: '4px',
                      width: '30%'
                    }}
                  >
                    51h Place ( Finalist)
                  </th>
                  <td style={{ border: '1px solid#000', textAlign: 'left', padding: '4px' }}>
                    <input type="text" style={{ borderColor: '#ccc0', width: '100%' }}></input>
                  </td>
                </tr>
                <tr>
                  <th
                    style={{
                      border: '1px solid#000',
                      textAlign: 'left',
                      padding: '4px',
                      width: '30%'
                    }}
                  >
                    Sixth Place ( Finalist)
                  </th>
                  <td style={{ border: '1px solid#000', textAlign: 'left', padding: '4px' }}>
                    <input type="text" style={{ borderColor: '#ccc0', width: '100%' }}></input>
                  </td>
                </tr>
                <tr>
                  <th
                    style={{
                      border: '1px solid#000',
                      textAlign: 'left',
                      padding: '4px',
                      width: '30%'
                    }}
                  >
                    Saventh Place ( Finalist)
                  </th>
                  <td style={{ border: '1px solid#000', textAlign: 'left', padding: '4px' }}>
                    <input type="text" style={{ borderColor: '#ccc0', width: '100%' }}></input>
                  </td>
                </tr>
                <tr>
                  <th
                    style={{
                      border: '1px solid#000',
                      textAlign: 'left',
                      padding: '4px',
                      width: '30%'
                    }}
                  >
                    Eighth Place ( Finalist)
                  </th>
                  <td style={{ border: '1px solid#000', textAlign: 'left', padding: '4px' }}>
                    <input type="text" style={{ borderColor: '#ccc0', width: '100%' }}></input>
                  </td>
                </tr>
              </table>
            </div>
          </div>
          {/* second table result close */}
        </div>

        {/* block-3 close */}

        <div style={{ width: '100%', marginTop: '10px', marginBottom: '30px' }}>
          <h2 style={{ marginBottom: '30px', textAlign: 'center' }}>16 Bracket Example</h2>
          <BracketSixteen />
        </div>

        <div style={{ width: '100%', marginTop: '30px', marginBottom: '30px' }}>
          <h2 style={{ marginBottom: '30px', textAlign: 'center' }}>32 Bracket Example</h2>
          <BracketThirtyTwo />
        </div>
      </div>
    </>
  );
}

export default DivisionSheet;
