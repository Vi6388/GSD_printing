import React, { Fragment, useState } from 'react';
import {
  Button,
  Card,
  Col,
  Input,
  Label,
  Modal,
  ModalBody,
  ModalFooter,
  ModalHeader,
  Row
} from 'reactstrap';
import { Link } from 'react-router-dom';
const BracketingMain = () => {
  const [active, setActive] = useState('1');
  const [open, setOpen] = useState(false);

  const toggle = (tab) => {
    if (active !== tab) {
      setActive(tab);
    }
  };
  return (
    <Fragment>
      <Card className="p-1">
        <div>
          <h4>2023 CMA BROOKLYN REGIONAL CHAMPIONSHIPS</h4>
        </div>
        <div>
          <div
            className="p-1"
            style={{
              backgroundColor: '#c52f2f',
              color: '#fff',
              borderRadius: '6px 6px 0px 0px'
            }}
          >
            <span>
              <b>Bracketing</b>
            </span>
          </div>
          <div>
            <div className="my-1">
              <span style={{ color: 'blue', marginRight: '3px' }}>
                <b>MASTER RESET: Emergency use only!</b>
              </span>
              <span>Re-sort Members into Divisions. Overwrites ALL division changes!:</span>
              <Button className="ms-1" color="primary">
                Reset Division
              </Button>
            </div>
            <h4>Step 1: Sort Members</h4>
            <div style={{ borderTop: '1px solid #e5e5e5' }}>
              <div className="mt-1">
                <span>
                  Weight, School, or Random. Weight tries to place Members together by closest
                  weight, school places people so they won't compete against Members from the same
                  school. Random means random placements. Most of the time you will choose School.
                  Tourneyreg now Auto Sorts so you don't need to remember to. If you manually sort a
                  division you will need to lock it, or the auto sort will override the manual sort!
                </span>
              </div>
              <Row className="my-1">
                <Col sm={4} lg={4} md={4}>
                  <div>
                    <span>Current Auto Sort Method:</span>
                    <span style={{ color: 'green' }}>
                      <b>School</b>
                    </span>
                  </div>
                  <div className="d-flex">
                    <Input type="select" style={{ width: '150px' }}>
                      <option>School</option>
                      <option>Random</option>
                      <option>Weight</option>
                    </Input>
                    <Button className="ms-1" color="primary">
                      Change Sort Type
                    </Button>
                  </div>
                </Col>
                <Col sm={4} lg={4} md={4}>
                  <div className="d-flex justify-content-center align-items-end">
                    <h3>OR</h3>
                    <div className="ms-2">
                      <Input type="number" style={{ width: '95px' }} />
                      <Button className="mt-1" color="primary">
                        Submit
                      </Button>
                    </div>
                  </div>
                </Col>
                <Col sm={4} lg={4} md={4}>
                  <div>
                    <span>Manually Sort This Division</span>
                  </div>
                </Col>
              </Row>
              <center style={{ color: 'red' }}>OR</center>
            </div>
            <h4>Step 2: Print Brackets</h4>
            <div style={{ borderTop: '1px solid #e5e5e5' }}>
              <div className="mt-1">
                <span>
                  <b>Display/Printing Division Sheets.</b>
                </span>
                <div>
                  <span>Choose an event to print brackets:</span>
                </div>
              </div>
              <div>
                <Input type="select" style={{ width: '300px' }}>
                  <option>Black Belt Breaking</option>
                  <option>Black Belt Creative Form</option>
                  <option>Black Belt Grassroots Sparring</option>
                  <option>Black Belt Power Breaking</option>
                  <option>Black Belt Sports Form</option>
                  <option>Black Belt Team Form</option>
                </Input>
                <Row>
                  <Col sm={4} lg={4} md={4}></Col>
                  <Col sm={4} lg={4} md={4}></Col>
                </Row>
                <div className="d-flex align-items-center mt-1">
                  <span>Limited By Rank From:</span>
                  <Input type="select" style={{ width: '200px' }}>
                    <option>No Belt</option>
                    <option>White Belt</option>
                    <option>Black Belt</option>
                    <option>Green Belt</option>
                    <option>Blue Belt</option>
                    <option>Red Belt</option>
                  </Input>
                  <span>Limited By Rank To:</span>
                  <Input type="select" style={{ width: '180px' }}>
                    <option>No Belt</option>
                    <option>White Belt</option>
                    <option>Black Belt</option>
                    <option>Green Belt</option>
                    <option>Blue Belt</option>
                    <option>Red Belt</option>
                  </Input>
                  <span> and/or Gender:</span>
                  <Input type="select" style={{ width: '150px' }}>
                    <option>No Belt</option>
                    <option>White Belt</option>
                    <option>Black Belt</option>
                    <option>Green Belt</option>
                    <option>Blue Belt</option>
                    <option>Red Belt</option>
                  </Input>
                  <span>and/or ages from</span>
                  <Input type="number" style={{ width: '95px' }} />
                  <span>to</span>
                  <Input type="number" style={{ width: '95px' }} />
                </div>
                <span style={{ color: 'red' }}>
                  *new: to split divisions by age type in the age you want (div is 6-7: just want 6
                  type 6 into both upper and lower age limits). Works with single div too!
                </span>
                <div className="d-flex align-items-center">
                  <span>or one div</span>
                  <Input type="number" style={{ width: '70px' }} />
                </div>
                <div className="mt-2">
                  <div>
                    <Input type="radio" />
                    <span className="ms-1">print as a list</span>
                  </div>
                  <div>
                    <Input type="radio" defaultChecked />
                    <span className="ms-1">print as bracketed</span>
                  </div>
                  <div>
                    <Input type="radio" />
                    <span className="ms-1">print Vertical bracketing?</span>
                  </div>
                  <div>
                    <Input type="radio" defaultChecked />
                    <span className="ms-1">print Landscape bracketing?</span>
                  </div>
                  <div>
                    <Input type="checkbox" />
                    <span className="ms-1">print double elimination? (12 or less competitors)</span>
                  </div>
                  <div>
                    <Input type="checkbox" />
                    <span className="ms-1">
                      print Brazilian Repechage bracketing? (16 or less competitors/bracket)
                    </span>
                  </div>
                </div>
                <div className="mt-1">
                  <Row>
                    <Col sm={6} lg={6} md={6}>
                      <div>
                        <Input type="select" style={{ width: '70px' }}>
                          <option>4</option>
                          <option>8</option>
                          <option>16</option>
                          <option>32</option>
                        </Input>
                        <Button
                          href="/divisionsheet"
                          target="_blank"
                          color="primary"
                          className="mt-1"
                        >
                          Open Division Sheet
                        </Button>
                      </div>
                    </Col>
                    <Col sm={6} lg={6} md={6}>
                      <span>
                        Limit to N competitors (ie, no more than 4 in a division before it breaks
                        into subdivisions)
                      </span>
                    </Col>
                  </Row>
                </div>
              </div>
            </div>
            <div className="mt-1">
              <h4>Step 3: Report Results</h4>
              <div style={{ borderTop: '1px solid #e5e5e5' }}>
                <div className="mt-1">
                  <Row>
                    <Col sm={6} lg={6} md={6}>
                      <div className="d-flex justify-content-end align-items-center">
                        <span style={{ color: '#999' }}>
                          Report Division Placement - Type in Division ID here:
                        </span>
                        <Input type="text" style={{ width: '70px' }} />
                      </div>
                    </Col>
                    <Col sm={6} lg={6} md={6}>
                      <div className="d-flex justify-content-center">
                        <Button href="/newPage" color="primary">
                          Open Division Sheet
                        </Button>
                      </div>
                    </Col>
                  </Row>
                </div>
                <div className="mt-1">
                  <center>
                    <span style={{ color: 'red' }}>{'[Export Placements Only]'}</span>
                    <span>OR</span>
                    <span style={{ color: 'red' }}>{'[Export Everyone]'}</span>
                    <span>OR</span>
                    <span style={{ color: 'red' }}>
                      {'[Export AAU Report] [Export AAU Olympic Report]'}
                    </span>
                  </center>
                </div>
              </div>
            </div>
            <div className="mt-1">
              <h4>Print Blank Division Sheets</h4>
              <div style={{ borderTop: '1px solid #e5e5e5' }}>
                <div className="mt-1">
                  <Row>
                    <Col sm={6} lg={6} md={6}>
                      <Input type="select" style={{ width: '300px' }}>
                        <option>No Belt</option>
                        <option>White Belt</option>
                        <option>Black Belt</option>
                        <option>Green Belt</option>
                        <option>Blue Belt</option>
                        <option>Red Belt</option>
                      </Input>
                    </Col>
                    <Col sm={6} lg={6} md={6}>
                      <span>Event Type</span>
                    </Col>
                  </Row>
                </div>
                <div className="mt-2">
                  <div>
                    <Input type="radio" />
                    <span className="ms-1">print as a list</span>
                  </div>
                  <div>
                    <Input type="radio" defaultChecked />
                    <span className="ms-1">print as bracketed</span>
                  </div>
                  <div>
                    <Input type="radio" />
                    <span className="ms-1">print Vertical bracketing?</span>
                  </div>
                  <div>
                    <Input type="radio" defaultChecked />
                    <span className="ms-1">print Landscape bracketing?</span>
                  </div>
                  <div>
                    <Input type="checkbox" />
                    <span className="ms-1">print double elimination? (12 or less competitors)</span>
                  </div>
                  <div>
                    <Input type="checkbox" />
                    <span className="ms-1">
                      print Brazilian Repechage bracketing? (16 or less competitors/bracket)
                    </span>
                  </div>
                </div>
                <div className="mt-1">
                  <Row>
                    <Col sm={6} lg={6} md={6}>
                      <div>
                        <Input type="select" style={{ width: '70px' }}>
                          <option>4</option>
                          <option>8</option>
                          <option>16</option>
                          <option>32</option>
                        </Input>
                        <Button href="/blackbeltcreativeform" className="mt-1" color="primary">
                          {' '}
                          Create Blank Sheet
                        </Button>
                      </div>
                    </Col>
                    <Col sm={6} lg={6} md={6}>
                      <span> Number of Members in Brackets</span>
                    </Col>
                  </Row>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Card>
      <Modal toggle={() => setOpen(false)} className="modal-dialog-centered" isOpen={open}>
        <ModalHeader className="bg-transparent" toggle={() => setOpen((p) => !p)}></ModalHeader>
        <ModalBody className="px-sm-5 mx-50 pb-5">
          <div>
            <h3 className="text-center mb-1">Set Rounds And Rings</h3>
            <Row>
              <Col sm={6} lg={6} md={6}>
                <Label>Rounds</Label>
                <Input type="select">
                  <option>1</option>
                  <option>2</option>
                  <option>3</option>
                  <option>4</option>
                  <option>5</option>
                  <option>6</option>
                </Input>
              </Col>
              <Col sm={6} lg={6} md={6}>
                <Label>Rings</Label>
                <Input type="select">
                  <option>1</option>
                  <option>2</option>
                  <option>3</option>
                  <option>4</option>
                  <option>5</option>
                  <option>6</option>
                  <option>7</option>
                  <option>8</option>
                  <option>9</option>
                  <option>10</option>
                  <option>11</option>
                  <option>12</option>
                  <option>13</option>
                  <option>14</option>
                  <option>15</option>
                  <option>16</option>
                  <option>17</option>
                  <option>18</option>
                  <option>19</option>
                  <option>20</option>
                  <option>21</option>
                  <option>22</option>
                  <option>23</option>
                  <option>24</option>
                </Input>
              </Col>
            </Row>
          </div>
        </ModalBody>
        <ModalFooter className="d-flex justify-content-between ">
          <Button className="mt-1 me-3" outline onClick={() => setOpen(false)}>
            Cancel
          </Button>
          <Button className="mt-1" color="primary">
            Confirm
          </Button>
        </ModalFooter>
      </Modal>
    </Fragment>
  );
};
export default BracketingMain;
